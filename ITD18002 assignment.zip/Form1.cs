﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        string[,] array = new string[5, 3];
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string name = textBox1.Text;
        }

        private void button18_Validating(object sender, CancelEventArgs e)
        {

        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                e.Cancel = true;
                textBox2.Focus();
                errorProviderApp.SetError(textBox2, "Name should not be left blank!");
            }
            else
            {
                e.Cancel = false;
                errorProviderApp.SetError(textBox2, "");
            }
        }

       // private void button18_Click(object sender, EventArgs e)
       

      //  private void listBox1_SelectedIndexChanged(object sender, EventArgs e)

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
           
        }

        private void button17_Click(object sender, EventArgs e)
        {
            
        }

        private void button20_Click(object sender, EventArgs e)
        {
            richTextBox2.Text=textBox1.Text;
        }
    
        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
          }

        private void button21_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    array[i, j] = "AMAN";
                }
            }
        }

        private void listBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                e.Cancel = true;
                textBox1.Focus();
                errorProviderApp.SetError(textBox1, "select seat!");
            }
            else
            {
                e.Cancel = false;
                errorProviderApp.SetError(textBox1, "");
            }
        }

        private void listBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                e.Cancel = true;
                textBox1.Focus();
                errorProviderApp.SetError(textBox1, "select row!");
            }
            else
            {
                e.Cancel = false;
                errorProviderApp.SetError(textBox2, "");
            }
        }


        /*private void button1_Click(object sender, EventArgs e)
        {
            seat();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            seat();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            seat();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        { }
        }
    }

      // private void button1_Click(object sender, EventArgs e)
      private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }*/
    }
}

